import type { Plugin, UserConfig } from "vite";
import { loadEnv } from "vite";
import { errorOverlayPlugin } from "./error-overlay-plugin.js";
import { visualEditPlugin } from "./visual-edit-plugin.js";
import { filterPackagesInProject } from "./utils.js";
import { htmlInjectionsPlugin } from "./html-injections-plugin.js";

const isRunningInSandbox = !!process.env.MODAL_SANDBOX_ID;

export default function vitePlugin(
  opts: {
    legacySDKImports?: boolean;
    hmrNotifier?: boolean;
    navigationNotifier?: boolean;
    visualEditAgent?: boolean;
    analyticsTracker?: boolean;
  } = {}
) {
  const {
    legacySDKImports = false,
    hmrNotifier = false,
    navigationNotifier = false,
    visualEditAgent = false,
    analyticsTracker = false,
  } = opts;

  return [
    {
      name: "base44",
      config: ({ mode, root = process.cwd() }) => {
        const env = loadEnv(mode ?? "development", root, "");

        return {
          resolve: {
            alias: {
              "@/": "/src/",
            },
          },
          ...(legacySDKImports
            ? {
                define: {
                  "process.env.VITE_BASE44_APP_ID": JSON.stringify(
                    env.VITE_BASE44_APP_ID
                  ),
                  "process.env.VITE_BASE44_BACKEND_URL": JSON.stringify(
                    env.VITE_BASE44_BACKEND_URL
                  ),
                },
              }
            : {}),
          ...(isRunningInSandbox
            ? ({
                server: {
                  cors: true,
                  host: "0.0.0.0", // Bind to all interfaces for container access
                  port: 5173,
                  strictPort: true,
                  // Allow all hosts - essential for Modal tunnel URLs
                  allowedHosts: true,
                  // Route the HMR WebSocket through the preview proxy instead of
                  // the sandbox origin. When BASE44_HMR_HOST is unset (e.g. before
                  // the proxy is deployed), fall back to Vite's default behavior
                  // and connect to window.location.host.
                  ...(process.env.BASE44_HMR_HOST
                    ? { hmr: { host: process.env.BASE44_HMR_HOST } }
                    : {}),
                  watch: {
                    // Enable polling for better file change detection in containers
                    usePolling: true,
                    interval: 100, // Check every 100ms for responsive HMR
                    // Wait for file writes to complete before triggering HMR
                    awaitWriteFinish: {
                      stabilityThreshold: 150,
                      pollInterval: 50,
                    },
                  },
                },
                build: {
                  rollupOptions: {
                    onwarn(warning, warn) {
                      // Treat import errors as fatal errors
                      if (
                        warning.code === "UNRESOLVED_IMPORT" ||
                        warning.code === "MISSING_EXPORT"
                      ) {
                        throw new Error(`Build failed: ${warning.message}`);
                      }
                      // Use default for other warnings
                      warn(warning);
                    },
                  },
                },
              } as Partial<UserConfig>)
            : (() => {
                if (env.VITE_BASE44_APP_BASE_URL) {
                  console.log(
                    `[base44] Proxy enabled: /api -> ${env.VITE_BASE44_APP_BASE_URL}`
                  );
                  return {
                    server: {
                      proxy: {
                        "/api": {
                          target: env.VITE_BASE44_APP_BASE_URL,
                          changeOrigin: true,
                        },
                      },
                    },
                  };
                }
                console.log(
                  "[base44] Proxy not enabled (VITE_BASE44_APP_BASE_URL not set)"
                );
                return {};
              })()),
          optimizeDeps: {
            ...(isRunningInSandbox
              ? {
                  include: filterPackagesInProject(
                    [
                      "react",
                      "react-dom",
                      "framer-motion",
                      "lodash",
                      "moment",
                      "react-quill",
                    ],
                    root
                  ),
                }
              : {}),
            esbuildOptions: {
              loader: {
                ".js": "jsx",
              },
            },
          },
        };
      },
      async resolveId(source, importer, options) {
        // only resolve imports in the legacy SDK if they are not in an HTML file
        // because we might have pages that include /integrations, /functions, etc.
        if (legacySDKImports && !importer?.endsWith(".html")) {
          const existingResolution = await this.resolve(
            source,
            importer,
            options
          );

          if (existingResolution) {
            return existingResolution;
          }

          // in legacy apps, the AI sometimes imports components from the Layout with `../`
          // which breaks when monving to the vite template, so this solved it by
          // resolving the path to the components folder
          if (
            importer?.endsWith("/src/Layout.jsx") &&
            source.startsWith("../components")
          ) {
            return this.resolve(
              source.replace(/^..\/components/, "@/components"),
              importer,
              options
            );
          }

          // Handle imports of Layout.js or Layout.jsx from pages directory
          if (
            importer?.includes("/pages") &&
            (source.toLowerCase().endsWith("layout.jsx") ||
              source.toLowerCase().endsWith("layout.js"))
          ) {
            return this.resolve("@/Layout.jsx", importer, options);
          }

          if (source.includes("/entities")) {
            return this.resolve(
              "@base44/vite-plugin/compat/entities.cjs",
              importer,
              options
            );
          }

          if (source.includes("/functions")) {
            return this.resolve(
              "@base44/vite-plugin/compat/functions.cjs",
              importer,
              options
            );
          }

          if (source.includes("/integrations")) {
            return this.resolve(
              "@base44/vite-plugin/compat/integrations.cjs",
              importer,
              options
            );
          }

          if (source.includes("/agents")) {
            return this.resolve(
              "@base44/vite-plugin/compat/agents.cjs",
              importer,
              options
            );
          }
        }

        return null;
      },
    } as Plugin,
    ...(isRunningInSandbox
      ? [
          {
            name: "iframe-hmr",
            configureServer(server) {
              server.middlewares.use((req, res, next) => {
                // Allow iframe embedding
                res.setHeader("X-Frame-Options", "ALLOWALL");
                res.setHeader("Content-Security-Policy", "frame-ancestors *;");
                next();
              });
            },
          } as Plugin,
          errorOverlayPlugin(),
          visualEditPlugin(),
        ]
      : []),
    // HTML injections - handles both dev (sandbox) and production injections
    htmlInjectionsPlugin({ hmrNotifier, navigationNotifier, visualEditAgent, analyticsTracker }),
  ];
}
